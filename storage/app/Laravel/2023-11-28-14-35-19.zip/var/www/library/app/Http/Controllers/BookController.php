<?php

namespace App\Http\Controllers;
use App\Models\Book;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\File;
class BookController extends Controller
{

    public function index()
    {
        $books = Book::get();
        return view('index', ['books' => $books]);
    }


    public function dashboard()
{
    $books = Book::all(); // Retrieve all books

    return view('dashboard', ['books' => $books]);
}



public function store(Request $request)
{
    // Validate incoming request data
    $validatedData = $request->validate([
        'title' => 'required',
        'author' => 'required',
        'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048', // Adjust file types and size as needed
        'pdf_file' => 'required|mimes:pdf|max:2048',
    ]);

    // Store cover image in the specified directory (storage/app/public/images)
    $imagePath = $request->file('image')->store('images', 'public'); 

    // Store PDF file in the specified directory (storage/app/public/pdf_files)
    $pdfPath = $request->file('pdf_file')->store('pdf_files', 'public'); 

    // Create a new Book instance and save it to the database
    $book = new Book([
        'title' => $validatedData['title'],
        'author' => $validatedData['author'],
        'image_path' => $imagePath,
        'pdf_path' => $pdfPath,
    ]);

    $book->save();

    return redirect('/dashboard')->with('success', 'Book stored successfully.');
}
    

    public function edit($id)
{
    $book = Book::findOrFail($id); // Retrieve the book by ID

    // You can pass $book to a view to populate the edit form
    return view('books.edit', compact('book'));
}


public function update(Request $request, $id)
{
    $book = Book::findOrFail($id);

    $validatedData = $request->validate([
        'title' => 'required',
        'author' => 'required',
        'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048', // Adjust file types and size as needed
        'pdf_file' => 'mimes:pdf|max:2048',
    ]);

    $book->title = $validatedData['title'];
    $book->author = $validatedData['author'];

    if ($request->hasFile('image')) {
        Storage::delete('public/' . $book->image_path);
        $book->image_path = $request->file('image')->store('images', 'public');
    }

    if ($request->hasFile('pdf_file')) {
        Storage::delete('public/' . $book->pdf_path);
        $book->pdf_path = $request->file('pdf_file')->store('pdf_files', 'public');
    }

    $book->save();

    return redirect('/dashboard')->with('success', 'Book updated successfully.');
}



    public function destroy(Book $book)
    {
        $book = Book::findOrFail($book->id);
        // Delete the image file
Storage::delete('public/' . $book->image_path);

// Delete the PDF file
Storage::delete('public/' . $book->pdf_path);
        $book->delete();
        return back()->with(['operation'=>'deleted', 'id'=>$book->id]);
    }


    


}
