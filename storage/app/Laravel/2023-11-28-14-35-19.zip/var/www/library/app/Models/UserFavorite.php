<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserFavorite extends Model
{
    protected $table = 'user_favorites'; // Replace with your actual table name if different

    protected $fillable = [
        'user_id',
        'book_id',
    ];

    // Relationship with the User model
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relationship with the Book model
    public function book()
    {
        return $this->belongsTo(Book::class);
    }
}

