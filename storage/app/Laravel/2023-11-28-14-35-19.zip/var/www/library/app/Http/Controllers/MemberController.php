<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserFavorite;
class MemberController extends Controller
{
    public function dashboard()
    {
        // Logic specific to member dashboard
        return view('/memberdashboard'); // Remove the leading '/' in the view path
    }
    

   
}
