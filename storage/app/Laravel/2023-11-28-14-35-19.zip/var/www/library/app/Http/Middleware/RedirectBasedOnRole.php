<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RedirectBasedOnRole
{
    public function handle(Request $request, Closure $next, ...$roles)
    {
        $user = Auth::user();

        if ($user && in_array($user->role, $roles)) {
            switch ($user->role) {
                case 'admin':
                    return redirect('/dashboard');
                case 'member':
                    return redirect('/memberdashboard');
                // Add other role-specific cases as needed
            }
        }

        return $next($request);
    }
}