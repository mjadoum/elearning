<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\UserFavorite;

class FavoriteController extends Controller
{
    public function showMemberDashboard()
    {
        // Retrieve the currently authenticated user's favorite books
        $userFavorites = auth()->user()->userFavorites()->with('book')->get();

        // Pass the user's favorite books to the memberdashboard view
        return view('memberdashboard', ['userFavorites' => $userFavorites]);
    }


public function addToFavorites(Request $request)
{
    $userId = Auth::id(); // Get the logged-in user's ID
    $bookId = $request->input('book_id');

    // Check if the user has already favorited this book
    $userFavorite = UserFavorite::where('user_id', $userId)
        ->where('book_id', $bookId)
        ->first();

    if (!$userFavorite) {
        // Add the book to the user's favorites if it doesn't exist
        UserFavorite::create([
            'user_id' => $userId,
            'book_id' => $bookId,
        ]);

        return redirect()->route('index')->with('success', 'Book added to favorites successfully.');
    }

    return redirect()->route('index')->with('error', 'Book already exists in favorites.');
}



public function removeFromFavorites(Request $request)
{
    $userId = Auth::id();
    $bookId = $request->input('book_id');

    // Find the user's favorite book
    $userFavorite = UserFavorite::where('user_id', $userId)
        ->where('book_id', $bookId)
        ->first();

    if ($userFavorite) {
        // Remove the book from the user's favorites
        $userFavorite->delete();

        return redirect()->route('memberdashboard')->with('success', 'Book removed from favorites successfully.');
    }

    return redirect()->route('memberdashboard')->with('error', 'Book not found in favorites.');
}
}
