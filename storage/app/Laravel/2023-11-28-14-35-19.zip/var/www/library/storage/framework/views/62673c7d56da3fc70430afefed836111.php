
<?php /**PATH /var/www/library/resources/views/components/application-logo.blade.php ENDPATH**/ ?>