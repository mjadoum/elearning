<html>

<head>
<!-- CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/db676e76a0.js" crossorigin="anonymous"></script>
    <style>
        html {
            user-select: none;
        }

        .bg-green {
            background-color: green;
            color: white;
        }

        /* Style for form container */
        .book-form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;

            background-color: #f9f9f9;
        }

        h3 {
            margin: 20px auto !important;
            font-size: 30px !important;

        }

        /* Style for labels */
        label {
            font-weight: bold;
        }

        hr {
            height: 3px !important;
        }

        /* Style for input fields */
        input[type="text"],
        input[type="number"],
        input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 3px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .delt {
            width: 100%;
            padding: 8px;
            border-radius: 3px;
        }
        /* Style for submit button */
        .submit {
            background-color: #4caf50;
            color: #4caf50;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            padding: 8px;
            border-radius: 3px;
        }

        .submit:hover {
            background-color: #45a049;
        }
        .card{
        margin:10px auto;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); /* Adding a box-shadow */
        transition: box-shadow 0.3s ease-in-out; /* Adding a transition for smooth effect */
    }
    .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }
    </style>
    <title>Library | Dashboard</title>
</head>

<body>

    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight ">
                <?php echo e(__('Admin Dashboard')); ?>   
                <a class="nav-link text-end" href="/" >Go home page <i class="fas fa-arrow-right"></i></a>
            </h2>
            <h4 class="lead text-end"></h4>
         <?php $__env->endSlot(); ?>


        
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <h3 class="text-center">Insert new book</h3>
                     <div class="book-form ">
                        
            <form action="<?php echo e(url("dashboard")); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="title">Book title:</label><br>
                <input type="text" id="title" name="title" required><br><br>

                <label for="author">Author name:</label><br>
                <input type="text" id="author" name="author" required><br><br>

                <label for="image">Upload cover book:</label><br>
                <input type="file" id="image" name="image"><br><br>

                <label for="pdf">Upload PDF File:</label><br>
                <input type="file" id="pdf_file" name="pdf_file" accept=".pdf"><br><br>

                <input type="submit" value="Insert book" class=" submit btn btn-success">
            </form>
        </div>

       
                </div>
               
                <hr>
    
            </div>
            <div class="row">
                <h3 class="display-3">Delete current books</h3>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6 ">
               
                
                <div class="card mb-3" style="width: 14rem;">
                    <div class="card-header text-center">
                      No - <?php echo e($book->id); ?>

                    </div>
                    <ul class="list-group list-group-flush">
                      <li class="list-group-item"><strong>Title</strong> : <?php echo e($book->title); ?></li>
                      <li class="list-group-item"><strong>Author</strong> : <?php echo e($book->author); ?></li>

                      <li class="list-group-item">
                        <form method="POST" action='<?php echo e(url("dashboard/{$book->id}")); ?>' style="display:inline!important;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?> 
                            <input type="submit" value="Delete" class=" delt btn btn-outline-danger " >
                         </form>
                      </li>
                      <li class="list-group-item">
                       
                        <a href="<?php echo e(route('books.edit', $book->id)); ?>" class=" delt btn btn-outline-secondary ">Edit</a>
                       
                      </li>
                    </ul>
                  </div>
                 

              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        
        <script>
            // Show the div for 3 seconds
                document.addEventListener('DOMContentLoaded', function() {
                    var loggedInDiv = document.getElementById('loggedInMessage');
                    loggedInDiv.style.display = 'block'; // Display the div
            
                    setTimeout(function() {
                        loggedInDiv.style.display = 'none'; // Hide the div after 5 seconds
                    }, 3000); // 5000 milliseconds = 5 seconds
                });
        </script>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>

</html><?php /**PATH /var/www/library/resources/views//dashboard.blade.php ENDPATH**/ ?>