<html>

<head>
<!-- CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/db676e76a0.js" crossorigin="anonymous"></script>
     <!-- Fonts -->
     <link rel="preconnect" href="https://fonts.bunny.net">
     <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,opsz,wght@0,6..12,200;0,6..12,300;0,6..12,400;0,6..12,500;0,6..12,600;1,6..12,200;1,6..12,300;1,6..12,400&family=Nunito:wght@200;300;400;500;600&display=swap" rel="stylesheet">
    
    <style>
        html {
            user-select: none;
        }

        .bg-green {
            background-color: green;
            color: white;
        }

        /* Style for form container */
     

        h3 {
            font-family: 'Nunito', sans-serif;
            margin: 20px auto !important;
            font-size: 40px !important;

        }
        .card-img-top{
width: 150px;
margin: auto ;
    }
        /* Style for labels */
        label {
            font-weight: bold;
        }

        hr {
            height: 3px !important;
        }

        /* Style for input fields */
        input[type="text"],
        input[type="number"],
        input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 3px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .delt {
            width: 100%;
            padding: 8px;
            border-radius: 3px;
        }
        /* Style for submit button */
        .submit {
            background-color: #4caf50;
            color: #4caf50;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            padding: 8px;
            border-radius: 3px;
        }

        .submit:hover {
            background-color: #45a049;
        }
        .card{
        margin:10px auto;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); /* Adding a box-shadow */
        transition: box-shadow 0.3s ease-in-out; /* Adding a transition for smooth effect */
    }
    .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }
    .favorited {
        background-color: rgb(255, 166, 0);
        color: #fff;
    }
    .btn-remove{
        padding: 8px 16px;
        border:2px solid rgb(252, 79, 79) !important;
        background-color: rgba(255, 79, 79,0.9);
        color: red !important;
        transition: 0.7s;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    .btn-remove:hover {
        background-color: rgb(224, 37, 37);
        color: #fff !important;
        
    }
    .btn-remove:focus {
        outline: none;
        box-shadow: none;
    }
    .card{
        margin:10px auto;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); /* Adding a box-shadow */
        transition: box-shadow 0.3s ease-in-out; /* Adding a transition for smooth effect */
    }
    .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }
    .card-img-top{
width: 150px;
margin: auto ;
    }
    .btn{
        width: 100%;
        font-family: 'Nunito', sans-serif;
        font-weight: 500;
        transition: 0.6s;
    }
    /* Define a keyframe animation */
@keyframes ring {
    0% {
        transform: scale(1);
        opacity: 1;
    }
    50% {
        transform: scale(1.2);
        opacity: 0.5;
    }
    100% {
        transform: scale(1.5);
        opacity: 0;
    }
}
/* CSS for the animation class */
.ring-animation {
    animation: ring .5s ease-in-out;
}
    </style>
    <title>Library | User Account</title>
</head>

<body>

    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight ">
                <?php echo e(__('Account Dashboard')); ?>   
                <a class="nav-link text-end" href="/" >Return home page <i class="fas fa-arrow-right"></i></a>
            </h2>
            <h4 class="lead text-end"></h4>
         <?php $__env->endSlot(); ?>


        
        <div class="container">
            <div class="row mt-4">
                  <!-- Alert for success message -->
<?php if(session('success')): ?>
<div class="alert alert-success" id="successAlert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<!-- Alert for error message -->
<?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
                <h3 class="lead text-center">Favourit Books</h3>
            </div>
            <div class="row mt-4">
                <?php if($userFavorites->isEmpty()): ?>
                <img src="<?php echo e(asset('favorite.png')); ?>" class="card-img-top rounded mt-2 p-1" alt="cover book">

    <p class="lead text-center mt-5">Your favorite books list is empty, Try to add some from <a href="/" class="btn-link" style="color: #0091fc;">here</a> .</p>
<?php else: ?>
                <?php $__currentLoopData = $userFavorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userFavorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6">
                    <div class="card" style="width: 15rem;">
                        <img src="<?php echo e(url('storage/' . $userFavorite->book->image_path)); ?>" class="card-img-top rounded mt-2 p-1" alt="cover book">
                        <div class="card-body">
                            <h5 class="card-title text-center"><?php echo e($userFavorite->book->title); ?></h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">Author: <span><?php echo e($userFavorite->book->author); ?></span></li>
                                <li class="list-group-item">Publish date: <span><?php echo e($userFavorite->book->created_at->format('d/m/Y')); ?></span></li>
                                <li class="list-group-item">
                                    <a href="<?php echo e(asset('storage/' . $userFavorite->book->pdf_path)); ?>" class="btn btn-outline-success btn-download" download>
                                        <i class="fas fa-arrow-down"></i> Download
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <form method="POST" action="<?php echo e(route('remove.from.favorites')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="book_id" value="<?php echo e($userFavorite->book->id); ?>">
                                        <button type="submit" class="btn btn-remove"><i class="fas fa-trash"></i> Remove book</button>
                                    </form>
                                 
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
                
                    
                    
                        
    

            
        

       
               
               
                
    
            </div>
         
        </div>
        
        <script>
            function toggleFavorite(button) {
    if (button.classList.contains('favorited')) {
        button.classList.remove('favorited');
        button.innerHTML = '<i class="fas fa-heart"></i> Add To List';
    } else {
        button.classList.add('favorited');
        button.innerHTML = '<i class="fas fa-heart"></i> Added';
        button.querySelector('i').classList.add('ring-animation');
        setTimeout(() => {
            button.querySelector('i').classList.remove('ring-animation');
        }, 1000); // Adjust this time to match the animation duration
    }
}

// Automatically hide the success message after 3 seconds
setTimeout(function() {
    var successAlert = document.getElementById('successAlert');
    if (successAlert) {
        successAlert.style.display = 'none';
    }
}, 2000); // 3000 milliseconds = 3 seconds


</script>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>

</html><?php /**PATH /var/www/library/resources/views/memberdashboard.blade.php ENDPATH**/ ?>