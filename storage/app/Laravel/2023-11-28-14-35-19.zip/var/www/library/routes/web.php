<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\BookController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\FavoriteController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Display Book Details 
Route::get('/', [BookController::class, 'index'])->name('index');


// Store Book Details 
Route::post('/dashboard', [BookController::class, 'store']);

// User Roles Admin/Member auth
Route::get('/dashboard', [BookController::class, 'dashboard'])->middleware(['auth', 'verified'])->name('dashboard');
Route::get('/memberdashboard', [MemberController::class, 'dashboard'])->middleware(['auth', 'verified'])->name('memberdashboard');

// Delete Book Details 
Route::delete('/dashboard/{book}', [BookController::class, 'destroy']);

// Edit Book Details 
Route::get('/books/{id}/edit', [BookController::class, 'edit'])->name('books.edit');
Route::put('/books/{id}/edit', [BookController::class, 'update'])->name('books.update');

// Favourite Books ADD & REMOVE
Route::post('/add-to-favorites', [FavoriteController::class, 'addToFavorites'])->name('add.to.favorites');
Route::post('/remove-from-favorites', [FavoriteController::class, 'removeFromFavorites'])->name('remove.from.favorites');

// Member user Dashboard
Route::get('/memberdashboard', [FavoriteController::class, 'showMemberDashboard'])
    ->middleware(['auth']) // Add necessary middleware
    ->name('memberdashboard');


// Routes related to ProfileController
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';












