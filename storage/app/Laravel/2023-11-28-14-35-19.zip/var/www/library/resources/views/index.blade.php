<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MyBook | Home</title>
        {{-- Bootstrap 5 links --}}
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        {{-- Font Awesome --}}
        <script src="https://kit.fontawesome.com/db676e76a0.js" crossorigin="anonymous"></script>
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        {{-- Google Fonts --}}
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,opsz,wght@0,6..12,200;0,6..12,300;0,6..12,400;0,6..12,500;0,6..12,600;1,6..12,200;1,6..12,300;1,6..12,400&family=Nunito:wght@200;300;400;500;600&display=swap" rel="stylesheet">
        
        <style>
            html, body{
                background-color: #f3f4f6;       

            }
            .navbar{
                background-color: #ffffff !important;
                box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); /* Adding a box-shadow */
            }
            .nav-link{
                font-family: 'Nunito', sans-serif;
                font-weight: 600;
                transition: 0.3s;
               
            }
            .navbar-brand{
                font-size: 1.4rem;
                padding: 0px 30px; 
                font-family: 'Nunito', sans-serif;
                font-weight: 600;
                transition: 0.3s;
                text-shadow: 2px 5px 4px rgba(102, 102, 102, 0.5);
            }
            .nav-link:hover {
                transform: scale(.99);
                transition: 0.7s;
            }
         
            .nav-link i {
                font-size: 15px;
            }
            h3, h5{
                font-family: 'Nunito', sans-serif;
                font-weight: 300;
            }
            h3 span{
                
                font-weight: 600;
                text-shadow: 2px 5px 4px rgba(102, 102, 102, 0.5);
            }
            li{
                font-family: 'Nunito', sans-serif;
                font-weight: 600;
            }
            li span{
                font-family: 'Nunito Sans', sans-serif;
                font-weight: 300;
            }
            /* .downloadBtn{
                margin: 10px 50px;
            } */
           
    .favorited {
        background-color: rgb(255, 166, 0);
        color: #fff;
    }
    .btn-save{
        padding: 8px 16px;
        border:2px solid rgb(255, 166, 0) !important;
        background-color: rgba(255, 166, 0,0.9);
        color: #ffff;
        transition: 0.7s;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    .btn-save:hover {
        background-color: rgb(255, 166, 0);
        color: #fff;
        
    }
    .btn-save:focus {
        outline: none;
        box-shadow: none;
    }
    .card{
        margin:10px auto;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); /* Adding a box-shadow */
        transition: box-shadow 0.3s ease-in-out; /* Adding a transition for smooth effect */
    }
    .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }
    .card-img-top{
width: 150px;
margin: auto ;
    }
    .btn{
        width: 100%;
        font-family: 'Nunito', sans-serif;
        font-weight: 600;
        transition: 0.6s;
    }
    
    
    /* Define a keyframe animation */
@keyframes ring {
    0% {
        transform: scale(1);
        opacity: 1;
    }
    50% {
        transform: scale(1.2);
        opacity: 0.5;
    }
    100% {
        transform: scale(1.5);
        opacity: 0;
    }
}
/* CSS for the animation class */
.ring-animation {
    animation: ring .5s ease-in-out;
}

/* Define the animation */
@keyframes arrowDown {
    0% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(5px);
    }
    100% {
        transform: translateY(0);
    }
}

/* Apply the animation to the arrow-down icon */
.btn-download .fas.fa-arrow-down {
    transition: transform 0.3s ease;
}

/* Add animation on click */
.btn-download.clicked .fas.fa-arrow-down {
    animation: arrowDown 0.5s;
}
.logout{
    color: red !important;
}

        </style>
    </head>
    <body >

        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                  <a class="navbar-brand" href="/"><i class="fas fa-book"></i> My Book</a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto px-4 py-0">
                        @if (Route::has('login'))
                        @auth
                     
                        <li class="nav-item">
                            @if(Auth::user()->role === 'admin')
                            <a href="{{ url('/dashboard') }}" class="nav-link font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Admin Dashboard</a>
                        @else
                            <a href="{{ url('/memberdashboard') }}" class="nav-link font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">My Account</a>
                        @endif
                            <li class="nav-item">
                            <x-dropdown-link class="nav-link" :href="route('profile.edit')">
                                {{ __('Profile') }}
                            </x-dropdown-link>
                            </li>
                            <li class="nav-item">
                            <!-- Authentication -->
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
    
                                <x-dropdown-link class="nav-link logout" :href="route('logout')"
                                        onclick="event.preventDefault();
                                                    this.closest('form').submit();">
                                    {{ __('Log Out') }}
                                </x-dropdown-link>
                            </form>
                            </li>
                            @else
                       

                            <a class="nav-link" style="" href="{{ route('login') }}" >Log in</a>
                           
                        </li>
                            
                          <li class="nav-item">
                            @if (Route::has('register'))
                            
                                <a class="nav-link" style="" href="{{ route('register') }}" >Register </a>
                            @endif
                          </li>

                        @endauth
                        @endif

                    </ul>
                  </div>
                </div>
              </nav>
        </header>

        <div class="container">
            <div class="row mt-4">
                <h3 class="text-center"><span>My Book</span>  library</h3>
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title text-center">You are Welcome in Your library</h3>
                        <p class="card-text lead ">Enhance your website experience by <b>creating a membership</b>. Simply click on the <b>'Register'</b> button to gain access. Once registered, you'll be able to <b>download</b> and add books to your <b>favorites list</b>, allowing easy access anytime you want.</p>
                    </div>
                </div>
               
                <!-- Alert for success message -->
@if(session('success'))
<div class="alert alert-success" id="Alert">
    {{ session('success') }}
</div>
@endif

<!-- Alert for error message -->
@if(session('error'))
<div class="alert alert-danger" id="Alert">
    {{ session('error') }}
</div>
@endif
            </div>
            @if (Route::has('login'))
            @auth
            @if(Auth::user()->role === 'admin')
            <div class="row mt-4">
                @foreach ($books as $book)
                <div class="col-lg-3 col-md-6 col-sm-4">
                    <div class="card mx-auto" style="width: 15rem;">
                        
                        <img src="{{ asset('storage/' . $book->image_path) }}" class="card-img-top rounded mt-2 p-1" alt="cover book">

                        <div class="card-body">
                            <h5 class="card-title text-center">{{$book->title}}</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">Author: <span>{{$book->author}}</span></li>
                                <li class="list-group-item">Publish date: <span>{{$book->created_at->format('d/m/Y') }}</span></li>
                                <li class="list-group-item">
                                    <a href="{{ asset('storage/' . $book->pdf_path) }}" class="btn btn-outline-success btn-download" download>
                                        <i class="fas fa-arrow-down"></i> Download
                                    </a>
                                </li>
                                {{-- <li class="list-group-item">
                                    

                                    <button class="btn btn-save" onclick="checkUserRole()">
                                        <i class="fas fa-heart"></i> Add To List
                                    </button>
                                </li> --}}
                            </ul>
                        </div>
                    </div>
                </div>
            @endforeach
            </div>
            @else
            <div class="row mt-4">
                @foreach ($books as $book)
                <div class="col-lg-3 col-md-6 col-sm-4">
                    <div class="card mx-auto" style="width: 15rem;">
                        
                        <img src="{{ asset('storage/' . $book->image_path) }}" class="card-img-top rounded mt-2 p-1" alt="cover book">

                        <div class="card-body">
                            <h5 class="card-title text-center">{{$book->title}}</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">Author: <span>{{$book->author}}</span></li>
                                <li class="list-group-item">Publish date: <span>{{$book->created_at->format('d/m/Y') }}</span></li>
                                <li class="list-group-item">
                                    <a href="{{ asset('storage/' . $book->pdf_path) }}" class="btn btn-outline-success btn-download" download>
                                        <i class="fas fa-arrow-down"></i> Download
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <form method="POST" action="{{ route('add.to.favorites') }}">
                                        @csrf
                                        <input type="hidden" name="book_id" value="{{ $book->id }}">
                                        <button type="submit" class="btn btn-save" onclick="toggleFavorite(this)"><i class="fas fa-heart"></i> Add To List
                                        </button>
                                    </form>

                                  
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            @endforeach
            @endif

      
            </div>                
            @else
            <div class="row mt-4">
                @foreach ($books as $book)
                <div class="col-lg-3 col-md-6 col-sm-4">
                    {{-- card div --}}
            <div class="card" style="width: 15rem;">
                <img src="{{ url('storage/' . $book->image_path) }}" class="card-img-top rounded mt-2 p-1" alt="cover book">
<div class="card-body">
                <h5 class="card-title text-center">{{$book->title}}</h5>
               
                <ul class="list-group list-group-flush">
                    
                    <li class="list-group-item">Author: <span>{{$book->author}}</span></li>
    
                    <li class="list-group-item">Publish date: <span>{{$book->created_at->format('d/m/Y') }}</span></li>
    
                  </ul>
                  
               
                </div>
              </div>
            {{-- End card div --}}
                  </div>
              
                  @endforeach

      
            </div>                   
                                      
            
            @endauth
            @endif
           

          </div>


      








        <div >
        </div>


        <script>
            function toggleFavorite(button) {
    if (button.classList.contains('favorited')) {
        button.classList.remove('favorited');
        button.innerHTML = '<i class="fas fa-heart"></i> Add To List';
    } else {
        button.classList.add('favorited');
        button.innerHTML = '<i class="fas fa-heart"></i> Added';
        button.querySelector('i').classList.add('ring-animation');
        setTimeout(() => {
            button.querySelector('i').classList.remove('ring-animation');
        }, 1000); // Adjust this time to match the animation duration
    }
}
// Get all elements with the class 'download-button'
const downloadButtons = document.querySelectorAll('.btn-download');

// Add click event listener to each button
downloadButtons.forEach(button => {
    button.addEventListener('click', function() {
        this.classList.add('clicked');
        setTimeout(() => {
            this.classList.remove('clicked');
        }, 500); // Adjust this time to match the animation duration
    });
});

// Automatically hide the success message after 3 seconds
setTimeout(function() {
    var successAlert = document.getElementById('Alert');
    if (successAlert) {
        successAlert.style.display = 'none';
    }
}, 2000); // 3000 milliseconds = 3 seconds



        </script>
    </body>
</html>
